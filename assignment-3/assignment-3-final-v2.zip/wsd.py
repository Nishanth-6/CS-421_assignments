import nltk
import re
import random
from typing import List

STOPWORDS = {
    "a", "an", "the", "and", "or", "but", "if", "while",
    "of", "at", "by", "for", "with", "about", "against",
    "between", "into", "through", "during", "before", "after",
    "to", "from", "in", "out", "on", "off", "over", "under",
    "again", "further", "then", "once",
    "here", "there", "all", "any", "both", "each", "few",
    "more", "most", "other", "some", "such",
    "no", "nor", "not", "only", "own", "same", "so", "than",
    "too", "very", "can", "will", "just", "do", "does", "did",
    "is", "am", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "having",
    "i", "you", "he", "she", "it", "we", "they",
    "me", "him", "her", "them",
    "my", "your", "his", "their", "our",
    "this", "that", "these", "those",
}

def load_sentences(_):
    from nltk.corpus import semcor
    try:
        return list(semcor.sents())
    except LookupError:
        nltk.download("semcor")
        return list(semcor.sents())

def load_tagged_sents(_):
    from nltk.corpus import semcor
    try:
        return semcor.tagged_sents(tag="sem")
    except LookupError:
        nltk.download("semcor")
        return semcor.tagged_sents(tag="sem")

def process_labels(tagged_sents):
    from nltk.tree import Tree
    processed = []
    for sent in tagged_sents:
        sent_labels = []
        for elem in sent:
            if isinstance(elem, Tree):
                label = elem.label()
                syn = None
                try:
                    syn = label.synset()
                except:
                    syn = None
                tokens = elem.leaves()
            else:
                syn = None
                tokens = [elem]

            for _ in tokens:
                sent_labels.append(syn)
        processed.append(sent_labels)
    return processed

def most_freq_sense_model(word):
    from nltk.corpus import wordnet as wn
    try:
        synsets = wn.synsets(word)
    except LookupError:
        nltk.download("wordnet")
        synsets = wn.synsets(word)
    return synsets[0] if synsets else None

def get_most_freq_predictions(sentences):
    preds = []
    for sent in sentences:
        row = []
        for word in sent:
            row.append(most_freq_sense_model(word.lower()))
        preds.append(row)
    return preds

def tokenize_gloss(text: str) -> List[str]:
    tokens = re.split(r"[^a-zA-Z]+", text.lower())
    return [t for t in tokens if t]

def lesk_model(word: str, sentence: List[str]):
    from nltk.corpus import wordnet as wn
    try:
        senses = wn.synsets(word)
    except LookupError:
        nltk.download("wordnet")
        senses = wn.synsets(word)

    if not senses:
        return None

    context = {w.lower() for w in sentence if w.lower() not in STOPWORDS}

    best_sense = senses[0]
    max_overlap = 0

    for sense in senses:
        signature = set(tokenize_gloss(sense.definition()))
        for ex in sense.examples():
            signature.update(tokenize_gloss(ex))

        signature = {w for w in signature if w not in STOPWORDS}
        overlap = len(context.intersection(signature))

        if overlap > max_overlap:
            max_overlap = overlap
            best_sense = sense
    return best_sense

def get_lesk_predictions(sentences):
    preds = []
    for sent in sentences:
        row = []
        for word in sent:
            row.append(lesk_model(word.lower(), sent))
        preds.append(row)
    return preds

def evaluate(gold, predicted):
    total_gold = 0
    total_pred = 0
    correct = 0

    for g_sent, p_sent in zip(gold, predicted):
        for g, p in zip(g_sent, p_sent):
            if g is not None:
                total_gold += 1
            if p is not None:
                total_pred += 1
            if g is not None and p is not None and g == p:
                correct += 1

    precision = correct / total_pred if total_pred else 0
    recall = correct / total_gold if total_gold else 0
    f1 = (2 * precision * recall / (precision + recall)) if (precision + recall) else 0
    return precision, recall, f1

def main():
    pass

if __name__ == "__main__":
    main()
