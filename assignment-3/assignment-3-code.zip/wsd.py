import random
import re
from typing import List

import nltk

# Simple built in English stopword list so we do not depend on NLTK's stopwords corpus
STOPWORDS = {
    "a", "an", "the", "and", "or", "but", "if", "while",
    "of", "at", "by", "for", "with", "about", "against",
    "between", "into", "through", "during", "before", "after",
    "to", "from", "in", "out", "on", "off", "over", "under",
    "again", "further", "then", "once",
    "here", "there", "all", "any", "both", "each", "few",
    "more", "most", "other", "some", "such",
    "no", "nor", "not", "only", "own", "same", "so", "than",
    "too", "very",
    "can", "will", "just", "do", "does", "did",
    "is", "am", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "having",
    "i", "you", "he", "she", "it", "we", "they",
    "me", "him", "her", "them",
    "my", "your", "his", "their", "our",
    "this", "that", "these", "those",
}

RANDOM_SEED = 42
NUM_SENTENCES = 50


def _get_semcor():
    """Return the NLTK SemCor corpus, downloading if needed."""
    from nltk.corpus import semcor
    try:
        _ = semcor.sents()
    except LookupError:
        nltk.download("semcor")
    return semcor


def _get_wordnet():
    """Return the NLTK WordNet corpus reader, downloading if needed."""
    from nltk.corpus import wordnet as wn
    try:
        _ = wn.synsets("test")
    except LookupError:
        nltk.download("wordnet")
    return wn


def load_sentences():
    """
    Q1.1 helper.
    Load SemCor sentences using NLTK and return them as a list of token lists.
    """
    semcor = _get_semcor()
    return list(semcor.sents())


def load_tagged_sents():
    """
    Q1.1 helper.
    Load SemCor tagged sentences with 'sem' tags.
    """
    semcor = _get_semcor()
    return semcor.tagged_sents(tag="sem")


def process_labels(tagged_sents):
    """
    Given SemCor tagged sentences, produce gold synset labels aligned with tokens.

    Each element in the returned list corresponds to a sentence and is itself
    a list of synsets (or None) aligned with the tokens from that sentence.
    """
    from nltk.tree import Tree

    processed = []

    for tagged_sent in tagged_sents:
        sent_labels = []
        for elem in tagged_sent:
            if isinstance(elem, Tree):
                label = elem.label()
                syn = None
                try:
                    syn = label.synset()
                except AttributeError:
                    syn = None
                tokens = elem.leaves()
            else:
                syn = None
                tokens = elem

            # repeat the synset for each surface token in this chunk
            for _tok in tokens:
                sent_labels.append(syn)

        processed.append(sent_labels)

    return processed


def _tokenize_text(text: str) -> List[str]:
    """
    Simple tokenizer for WordNet definitions and examples.
    """
    tokens = re.split(r"[^a-zA-Z]+", text.lower())
    return [t for t in tokens if t]


def most_freq_sense_model(word: str):
    """
    Q1.2 model.
    Given a word string, return its most frequent sense from WordNet,
    or None if the word has no synsets.
    """
    wn = _get_wordnet()
    synsets = wn.synsets(word)
    if not synsets:
        return None
    return synsets[0]


def get_most_freq_predictions(sentences: List[List[str]]):
    """
    Apply the Most Frequent Sense model to every token in each sentence.
    Returns a nested list of synsets or None.
    """
    predictions = []
    for sent in sentences:
        sent_preds = []
        for tok in sent:
            syn = most_freq_sense_model(tok.lower())
            sent_preds.append(syn)
        predictions.append(sent_preds)
    return predictions


def lesk_model(word: str, sentence_tokens: List[str]):
    """
    Q1.3 model.
    Simplified Lesk algorithm: choose the sense whose gloss has the
    highest overlap with the sentence context (excluding stopwords).
    """
    wn = _get_wordnet()
    senses = wn.synsets(word)
    if not senses:
        return None

    # context words
    context = {
        tok.lower()
        for tok in sentence_tokens
        if tok.lower() not in STOPWORDS and tok.isalpha()
    }

    best_sense = senses[0]
    max_overlap = 0

    for sense in senses:
        signature = set()

        # definition
        signature.update(_tokenize_text(sense.definition()))

        # examples
        for ex in sense.examples():
            signature.update(_tokenize_text(ex))

        signature = {w for w in signature if w not in STOPWORDS and w.isalpha()}
        overlap = len(context.intersection(signature))

        if overlap > max_overlap:
            max_overlap = overlap
            best_sense = sense

    return best_sense


def get_lesk_predictions(sentences: List[List[str]]):
    """
    Apply the Simplified Lesk model to every token in each sentence.
    Returns a nested list of synsets or None.
    """
    predictions = []
    for sent in sentences:
        sent_preds = []
        for tok in sent:
            syn = lesk_model(tok.lower(), sent)
            sent_preds.append(syn)
        predictions.append(sent_preds)
    return predictions


def evaluate(gold_labels, predicted_labels):
    """
    Compute precision, recall, and F1 using gold and predicted synset labels.

    gold_labels: list of list of synsets (or None)
    predicted_labels: list of list of synsets (or None)

    Only positions where the gold label is not None are part of the gold set.
    Positions where the prediction is not None are part of the predicted set.
    """
    assert len(gold_labels) == len(predicted_labels)

    gold_count = 0
    pred_count = 0
    correct = 0

    for gold_sent, pred_sent in zip(gold_labels, predicted_labels):
        for g, p in zip(gold_sent, pred_sent):
            if g is not None:
                gold_count += 1
            if p is not None:
                pred_count += 1
            if g is not None and p is not None and g == p:
                correct += 1

    precision = correct / pred_count if pred_count else 0.0
    recall = correct / gold_count if gold_count else 0.0

    if precision + recall == 0.0:
        f1 = 0.0
    else:
        f1 = 2 * precision * recall / (precision + recall)

    return precision, recall, f1


def main():
    """
    Local experiment script using SemCor.

    Not used by the autograder, but helpful to reproduce the results
    for the written part of the assignment.
    """
    random.seed(RANDOM_SEED)

    # Load data
    sentences = load_sentences()
    tagged = load_tagged_sents()
    labels = process_labels(tagged)

    # Randomly pick a subset of sentences for evaluation
    indices = random.sample(range(len(sentences)), NUM_SENTENCES)
    subset_sents = [sentences[i] for i in indices]
    subset_labels = [labels[i] for i in indices]

    # Ensure alignment
    aligned = []
    aligned_gold = []
    for s, g in zip(subset_sents, subset_labels):
        if len(s) == len(g):
            aligned.append(list(s))
            aligned_gold.append(list(g))

    # Most Frequent Sense
    mfs_preds = get_most_freq_predictions(aligned)
    mfs_p, mfs_r, mfs_f1 = evaluate(aligned_gold, mfs_preds)
    print(f"Most Frequent Sense: P={mfs_p:.4f} R={mfs_r:.4f} F1={mfs_f1:.4f}")

    # Simplified Lesk
    lesk_preds = get_lesk_predictions(aligned)
    lesk_p, lesk_r, lesk_f1 = evaluate(aligned_gold, lesk_preds)
    print(f"Simplified Lesk:     P={lesk_p:.4f} R={lesk_r:.4f} F1={lesk_f1:.4f}")


if __name__ == "__main__":
    main()
