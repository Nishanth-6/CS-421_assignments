import re
from typing import List, Tuple

import nltk

# Simple built in English stopword list so we do not depend on NLTK's stopwords corpus
STOPWORDS = {
    "a", "an", "the", "and", "or", "but", "if", "while",
    "of", "at", "by", "for", "with", "about", "against",
    "between", "into", "through", "during", "before", "after",
    "to", "from", "in", "out", "on", "off", "over", "under",
    "again", "further", "then", "once",
    "here", "there", "all", "any", "both", "each", "few",
    "more", "most", "other", "some", "such",
    "no", "nor", "not", "only", "own", "same", "so", "than",
    "too", "very", "can", "will", "just", "do", "does", "did",
    "is", "am", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "having",
    "i", "you", "he", "she", "it", "we", "they",
    "me", "him", "her", "them",
    "my", "your", "his", "their", "our",
    "this", "that", "these", "those",
}


# --------------------------------------------------------------------
# 1. Data loading helpers
# --------------------------------------------------------------------

def load_sentences(_dummy) -> List[List[str]]:
    """
    Load SemCor sentences as a list of token lists.
    Autograder passes a dummy argument, which we ignore.
    """
    from nltk.corpus import semcor
    try:
        return list(semcor.sents())
    except LookupError:
        nltk.download("semcor")
        return list(semcor.sents())


def load_tagged_sents(_dummy):
    """
    Load SemCor tagged sentences (tag='sem').
    Autograder passes a dummy argument, which we ignore.
    """
    from nltk.corpus import semcor
    try:
        return semcor.tagged_sents(tag="sem")
    except LookupError:
        nltk.download("semcor")
        return semcor.tagged_sents(tag="sem")


def process_labels(tagged_sents) -> Tuple[List[List[str]], List[List[object]]]:
    """
    Given SemCor tagged sentences, produce:
      sentences: list of list of surface tokens (strings)
      labels:    list of list of WordNet synsets (or None), aligned to tokens

    Returns a pair (sentences, labels).
    """
    from nltk.tree import Tree

    all_sentences: List[List[str]] = []
    all_labels: List[List[object]] = []

    for sent in tagged_sents:
        sent_tokens: List[str] = []
        sent_labels: List[object] = []

        for elem in sent:
            if isinstance(elem, Tree):
                label = elem.label()
                syn = None
                try:
                    syn = label.synset()
                except Exception:
                    syn = None
                tokens = elem.leaves()
            else:
                syn = None
                tokens = [elem]

            for t in tokens:
                sent_tokens.append(t)
                sent_labels.append(syn)

        all_sentences.append(sent_tokens)
        all_labels.append(sent_labels)

    return all_sentences, all_labels


# --------------------------------------------------------------------
# 2. Most Frequent Sense model
# --------------------------------------------------------------------

def most_freq_sense_model(word: str):
    """
    Given a word string, return its most frequent WordNet sense (a Synset),
    or None if the word has no synsets.
    """
    from nltk.corpus import wordnet as wn
    try:
        synsets = wn.synsets(word)
    except LookupError:
        nltk.download("wordnet")
        synsets = wn.synsets(word)
    return synsets[0] if synsets else None


def get_most_freq_predictions(sentences: List[List[str]]):
    """
    Apply the Most Frequent Sense model to each token in each sentence.

    sentences: list of list of tokens
    returns:   list of list of synsets (or None)
    """
    predictions: List[List[object]] = []
    for sent in sentences:
        row: List[object] = []
        for word in sent:
            syn = most_freq_sense_model(word.lower())
            # Either a Synset object or None
            row.append(syn if syn is not None else None)
        predictions.append(row)
    return predictions


# --------------------------------------------------------------------
# 3. Simplified Lesk model
# --------------------------------------------------------------------

def _tokenize_gloss(text: str) -> List[str]:
    tokens = re.split(r"[^a-zA-Z]+", text.lower())
    return [t for t in tokens if t]


def lesk_model(word: str, sentence: List[str]):
    """
    Simplified Lesk algorithm.

    word:     target word string
    sentence: list of tokens (context)
    returns:  best WordNet Synset for the word, or None
    """
    from nltk.corpus import wordnet as wn
    try:
        senses = wn.synsets(word)
    except LookupError:
        nltk.download("wordnet")
        senses = wn.synsets(word)

    if not senses:
        return None

    context = {w.lower() for w in sentence if w.lower() not in STOPWORDS}

    best_sense = senses[0]
    max_overlap = 0

    for sense in senses:
        signature = set(_tokenize_gloss(sense.definition()))
        for ex in sense.examples():
            signature.update(_tokenize_gloss(ex))
        signature = {w for w in signature if w not in STOPWORDS}

        overlap = len(context.intersection(signature))
        if overlap > max_overlap:
            max_overlap = overlap
            best_sense = sense

    # best_sense is always a Synset object
    return best_sense


def get_lesk_predictions(sentences: List[List[str]]):
    """
    Apply the Simplified Lesk model to each token in each sentence.

    sentences: list of list of tokens
    returns:   list of list of synsets (or None)
    """
    predictions: List[List[object]] = []
    for sent in sentences:
        row: List[object] = []
        for word in sent:
            syn = lesk_model(word.lower(), sent)
            row.append(syn if syn is not None else None)
        predictions.append(row)
    return predictions


# --------------------------------------------------------------------
# 4. Evaluation
# --------------------------------------------------------------------

def evaluate(gold, predicted):
    """
    Compute precision, recall, and F1 given gold and predicted synset labels.

    gold:      list of list of synsets (or None)
    predicted: list of list of synsets (or None)
    """
    total_gold = 0
    total_pred = 0
    correct = 0

    for g_sent, p_sent in zip(gold, predicted):
        for g, p in zip(g_sent, p_sent):
            if g is not None:
                total_gold += 1
            if p is not None:
                total_pred += 1
            if g is not None and p is not None and g == p:
                correct += 1

    precision = correct / total_pred if total_pred else 0.0
    recall = correct / total_gold if total_gold else 0.0
    f1 = (2 * precision * recall / (precision + recall)) if (precision + recall) else 0.0
    return precision, recall, f1


# --------------------------------------------------------------------
# 5. Main (ignored by autograder)
# --------------------------------------------------------------------

def main():
    # Left empty on purpose. Autograder only calls the functions above.
    pass


if __name__ == "__main__":
    main()
